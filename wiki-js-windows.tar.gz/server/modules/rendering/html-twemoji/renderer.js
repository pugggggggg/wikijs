// const twemoji = require('twemoji')

// ------------------------------------
// HTML - Twemoji
// ------------------------------------

module.exports = {
  init (input, conf) {
    // TODO: Must limit to text nodes only (exclude code blocks, already processed emojis, etc.)
    //
    // return twemoji.parse(input)
    return input
  }
}
